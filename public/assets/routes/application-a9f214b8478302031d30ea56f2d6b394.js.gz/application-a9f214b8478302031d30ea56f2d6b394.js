(function() {
  App.ApplicationRoute = Ember.Route.extend({
    queryParams: {
      kind: {
        replace: true,
        refreshModel: true
      }
    }
  });

}).call(this);
